here you should put the icons (only PNG) for each object in js/client/classes. Remember to name the files (js class and the icon) the same.
One icon "classname.png" is for the graph, but remember to provide also another icon "classname_toolbar.png" that will be used in the toolbar

icon graph color : #3498DB , 128 bit from flaticon.com

toolbar icon color: #2c3e50 , 64 bit from flaticon.com